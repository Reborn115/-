<template>
  <div id="root">
    <PersonalInfo ref="personalInformation"></PersonalInfo>
    <MajorList ref="majorInformation"></MajorList>
    <Expectation ref="expectations"></Expectation>

    <div class="">
      <div id="tiaoji">
        <h3>是否调剂</h3>
        <input
          class="testswitch-checkbox"
          id="onoffswitch"
          type="checkbox"
          v-model="isDispensing"
        />
        <label class="testswitch-label" for="onoffswitch">
          <span class="testswitch-inner" data-on="是" data-off="否"></span>
          <span class="testswitch-switch"></span>
        </label>
      </div>

      <div id="botton">
        <div type="submit" class="btn-signUp" @click="signup">
          <p>报名</p>
        </div>
        <div type="submit" class="btn-login" @click="login">
          <p>后台登录</p>
        </div>
      </div>

      <div>
        <p>仅供21级科协小可爱学习使用</p>
        <p>2022@政东</p>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import PersonalInfo from "../components/PersonalInfo.vue";
import MajorList from "../components/MajorList.vue";
import Expectation from "../components/Expectation.vue";
export default {
  name: "Sign",
  data() {
    return {
      isDispensing: true,
    };
  },
  components: {
    PersonalInfo,
    MajorList,
    Expectation,
  },
  methods: {
    login() {
      this.$router.push("/login");
    },
    signup() {
      let send = {
        stdId: this.$refs.personalInformation.stdId,
        stdName: this.$refs.personalInformation.stdName,
        major: this.$refs.majorInformation.majorandclassNum[0],
        classNum: this.$refs.majorInformation.majorandclassNum[1],
        stdQQ: this.$refs.personalInformation.stdQQ,
        stdPhone: this.$refs.personalInformation.stdPhone,
        firstWill: {
          organization: this.$refs.expectations.firstExpectation[0],
          branch: this.$refs.expectations.firstExpectation[1],
          reason: this.$refs.expectations.firstReason,
        },
        secondWill: {
          organization: this.$refs.expectations.secondExpectation[0],
          branch: this.$refs.expectations.secondExpectation[1],
          reason: this.$refs.expectations.secondReason,
        },
        isDispensing: this.isDispensing,
      };
      axios({
        method: "post",
        baseURL: "http://47.94.90.140:8000/",
        url: "/post",
        data: JSON.stringify(send),
        headers: {
          "content-type": "application/json",
        },
      })
        .then((value) => {
          alert("报名成功");
        })
        .catch((error) => {
          alert("报名失败，请检查内容");
        });
    },
  },
};
</script>

<style></style>
