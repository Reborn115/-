<template>
  <div>
    <div id="title">
      <h2>天津理工大学计算机科学与工程学院</h2>
      <h2>学生组织报名系统</h2>
    </div>

    <div id="personalInformation">
      <h3>个人信息</h3>
      <form>
        <input
          class="inputNormal"
          type="text"
          v-model="stdId"
          placeholder="请输入学号"
        /><br />
        <input
          class="inputNormal"
          type="text"
          v-model="stdName"
          placeholder="请输入姓名"
        /><br />
        <input
          class="inputNormal"
          type="text"
          v-model="stdQQ"
          placeholder="请输入QQ号"
        /><br />
        <input
          class="inputNormal"
          type="text"
          v-model="stdPhone"
          placeholder="请输入手机号"
        /><br />
      </form>
    </div>
  </div>
</template>

<script>
export default {
  name: "PersonalInfo",
  data() {
    return {
      stdId: "",
      stdName: "",
      stdQQ: "",
      stdPhone: "",
    };
  },
};
</script>

<style></style>
